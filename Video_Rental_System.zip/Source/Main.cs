using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Movie_Rental_Project
{
    
    public partial class Form1 : Form
    {
        //static public List<member> members = new List<member>();

        public Form1()
        {
            InitializeComponent();
        }





        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            // Make a new child window.
            membership_form newChild = new membership_form();

            // Set the Parent Form of the Child window.
            newChild.MdiParent = this;

            // Display the new form.
            newChild.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {



    
        }

         private void toolStripButton2_Click(object sender, EventArgs e)
         {
              // Make a new child window.
              inventory_form newChild = new inventory_form();

              // Set the Parent Form of the Child window.
              newChild.MdiParent = this;

              // Display the new form.
              newChild.Show();
         }

         private void toolStripButton3_Click(object sender, EventArgs e)
         {
              // Make a new child window.
              transaction_form newChild = new transaction_form();

              // Set the Parent Form of the Child window.
              newChild.MdiParent = this;

              // Display the new form.
              newChild.Show();
         }

        private void button1_Click(object sender, EventArgs e)
        {
            String a = "";
            a = textBox1.Text;
            if (a == "Tester")
            {
                a = textBox2.Text;
                if (a == "Test")
                {
                    toolStripButton1.Visible = true;
                    toolStripButton2.Visible = true;
                    toolStripButton3.Visible = true;

                    label1.Visible = false;
                    label2.Visible = false;
                    textBox1.Visible = false;
                    textBox2.Visible = false;
                    button2.Visible = false;
                    button1.Visible = false;
                }


            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }




    }
}