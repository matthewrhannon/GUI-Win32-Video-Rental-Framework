namespace Movie_Rental_Project
{
    partial class inventory_form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dlgSearch = new System.Windows.Forms.Button();
            this.dlgGrid = new System.Windows.Forms.DataGridView();
            this.Available = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Title = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numCopies = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.moviesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.dlgSearchText = new System.Windows.Forms.TextBox();
            this.dlgMedia = new System.Windows.Forms.ComboBox();
            this.dlgNewMedia = new System.Windows.Forms.GroupBox();
            this.dlgRating = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.dlgCostBuy = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.dlgNumCopies = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.dlgQuality = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.dlgGenre = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.dlgDescription = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.dlgFullTitle = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.dlgAdd = new System.Windows.Forms.Button();
            this.dlgDelete = new System.Windows.Forms.Button();
            this.dlgEdit = new System.Windows.Forms.Button();
            this.dlgAddNew = new System.Windows.Forms.Button();
            this.moviesBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dlgGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.moviesBindingSource)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.dlgNewMedia.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.moviesBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // dlgSearch
            // 
            this.dlgSearch.Location = new System.Drawing.Point(203, 19);
            this.dlgSearch.Name = "dlgSearch";
            this.dlgSearch.Size = new System.Drawing.Size(75, 23);
            this.dlgSearch.TabIndex = 2;
            this.dlgSearch.Text = "Search";
            this.dlgSearch.UseVisualStyleBackColor = true;
            this.dlgSearch.Click += new System.EventHandler(this.dlgSearch_Click);
            // 
            // dlgGrid
            // 
            this.dlgGrid.AllowUserToOrderColumns = true;
            this.dlgGrid.BackgroundColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.dlgGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dlgGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Available,
            this.Title,
            this.numCopies});
            this.dlgGrid.Location = new System.Drawing.Point(11, 48);
            this.dlgGrid.Name = "dlgGrid";
            this.dlgGrid.ReadOnly = true;
            this.dlgGrid.Size = new System.Drawing.Size(503, 150);
            this.dlgGrid.TabIndex = 3;
            this.dlgGrid.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dlgGrid_CellMouseClick);
            this.dlgGrid.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dlgGrid_CellContentClick);
            // 
            // Available
            // 
            this.Available.Frozen = true;
            this.Available.HeaderText = "ID";
            this.Available.Name = "Available";
            this.Available.ReadOnly = true;
            this.Available.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Available.Width = 55;
            // 
            // Title
            // 
            this.Title.Frozen = true;
            this.Title.HeaderText = "Title";
            this.Title.Name = "Title";
            this.Title.ReadOnly = true;
            this.Title.Width = 310;
            // 
            // numCopies
            // 
            this.numCopies.Frozen = true;
            this.numCopies.HeaderText = "Copies";
            this.numCopies.Name = "numCopies";
            this.numCopies.ReadOnly = true;
            // 
            // moviesBindingSource
            // 
            this.moviesBindingSource.DataMember = "Movies";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.comboBox1);
            this.groupBox1.Controls.Add(this.dlgSearchText);
            this.groupBox1.Controls.Add(this.dlgGrid);
            this.groupBox1.Controls.Add(this.dlgSearch);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(521, 209);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Inventory Selection";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(337, 24);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(71, 13);
            this.label9.TabIndex = 13;
            this.label9.Text = "Search Type:";
            // 
            // comboBox1
            // 
            this.comboBox1.Enabled = false;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(409, 19);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(103, 21);
            this.comboBox1.TabIndex = 5;
            // 
            // dlgSearchText
            // 
            this.dlgSearchText.Location = new System.Drawing.Point(14, 21);
            this.dlgSearchText.Name = "dlgSearchText";
            this.dlgSearchText.Size = new System.Drawing.Size(183, 20);
            this.dlgSearchText.TabIndex = 4;
            this.dlgSearchText.TextChanged += new System.EventHandler(this.dlgSearchText_TextChanged);
            // 
            // dlgMedia
            // 
            this.dlgMedia.Enabled = false;
            this.dlgMedia.FormattingEnabled = true;
            this.dlgMedia.Items.AddRange(new object[] {
            "Movies",
            "Games",
            "Other"});
            this.dlgMedia.Location = new System.Drawing.Point(386, 19);
            this.dlgMedia.Name = "dlgMedia";
            this.dlgMedia.Size = new System.Drawing.Size(126, 21);
            this.dlgMedia.TabIndex = 5;
            // 
            // dlgNewMedia
            // 
            this.dlgNewMedia.Controls.Add(this.dlgRating);
            this.dlgNewMedia.Controls.Add(this.label8);
            this.dlgNewMedia.Controls.Add(this.dlgMedia);
            this.dlgNewMedia.Controls.Add(this.dlgCostBuy);
            this.dlgNewMedia.Controls.Add(this.label7);
            this.dlgNewMedia.Controls.Add(this.label6);
            this.dlgNewMedia.Controls.Add(this.dlgNumCopies);
            this.dlgNewMedia.Controls.Add(this.label5);
            this.dlgNewMedia.Controls.Add(this.dlgQuality);
            this.dlgNewMedia.Controls.Add(this.label4);
            this.dlgNewMedia.Controls.Add(this.dlgGenre);
            this.dlgNewMedia.Controls.Add(this.label3);
            this.dlgNewMedia.Controls.Add(this.dlgDescription);
            this.dlgNewMedia.Controls.Add(this.label2);
            this.dlgNewMedia.Controls.Add(this.dlgFullTitle);
            this.dlgNewMedia.Controls.Add(this.label1);
            this.dlgNewMedia.Location = new System.Drawing.Point(12, 227);
            this.dlgNewMedia.Name = "dlgNewMedia";
            this.dlgNewMedia.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dlgNewMedia.Size = new System.Drawing.Size(521, 239);
            this.dlgNewMedia.TabIndex = 5;
            this.dlgNewMedia.TabStop = false;
            this.dlgNewMedia.Text = "Media Information";
            this.dlgNewMedia.Enter += new System.EventHandler(this.dlgNewMedia_Enter);
            // 
            // dlgRating
            // 
            this.dlgRating.Enabled = false;
            this.dlgRating.Location = new System.Drawing.Point(235, 202);
            this.dlgRating.Name = "dlgRating";
            this.dlgRating.Size = new System.Drawing.Size(277, 20);
            this.dlgRating.TabIndex = 14;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(14, 206);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(87, 13);
            this.label8.TabIndex = 13;
            this.label8.Text = "Rating and Why:";
            // 
            // dlgCostBuy
            // 
            this.dlgCostBuy.Enabled = false;
            this.dlgCostBuy.Location = new System.Drawing.Point(235, 176);
            this.dlgCostBuy.Name = "dlgCostBuy";
            this.dlgCostBuy.Size = new System.Drawing.Size(277, 20);
            this.dlgCostBuy.TabIndex = 11;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(14, 27);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(66, 13);
            this.label7.TabIndex = 12;
            this.label7.Text = "Media Type:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(14, 180);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(64, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "Cost to Buy:";
            // 
            // dlgNumCopies
            // 
            this.dlgNumCopies.Enabled = false;
            this.dlgNumCopies.Location = new System.Drawing.Point(235, 150);
            this.dlgNumCopies.Name = "dlgNumCopies";
            this.dlgNumCopies.Size = new System.Drawing.Size(277, 20);
            this.dlgNumCopies.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(14, 154);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(94, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Number of Copies:";
            // 
            // dlgQuality
            // 
            this.dlgQuality.Enabled = false;
            this.dlgQuality.Location = new System.Drawing.Point(235, 124);
            this.dlgQuality.Name = "dlgQuality";
            this.dlgQuality.Size = new System.Drawing.Size(277, 20);
            this.dlgQuality.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(14, 128);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Quality:";
            // 
            // dlgGenre
            // 
            this.dlgGenre.Enabled = false;
            this.dlgGenre.Location = new System.Drawing.Point(235, 98);
            this.dlgGenre.Name = "dlgGenre";
            this.dlgGenre.Size = new System.Drawing.Size(277, 20);
            this.dlgGenre.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(14, 102);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Genre:";
            // 
            // dlgDescription
            // 
            this.dlgDescription.Enabled = false;
            this.dlgDescription.Location = new System.Drawing.Point(235, 72);
            this.dlgDescription.Name = "dlgDescription";
            this.dlgDescription.Size = new System.Drawing.Size(277, 20);
            this.dlgDescription.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 76);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Description:";
            // 
            // dlgFullTitle
            // 
            this.dlgFullTitle.Enabled = false;
            this.dlgFullTitle.Location = new System.Drawing.Point(235, 46);
            this.dlgFullTitle.Name = "dlgFullTitle";
            this.dlgFullTitle.Size = new System.Drawing.Size(277, 20);
            this.dlgFullTitle.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Full Title:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.groupBox3);
            this.groupBox2.Controls.Add(this.dlgAdd);
            this.groupBox2.Controls.Add(this.dlgDelete);
            this.groupBox2.Controls.Add(this.dlgEdit);
            this.groupBox2.Controls.Add(this.dlgAddNew);
            this.groupBox2.Location = new System.Drawing.Point(15, 472);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(518, 47);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Location = new System.Drawing.Point(250, 9);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(10, 32);
            this.groupBox3.TabIndex = 4;
            this.groupBox3.TabStop = false;
            // 
            // dlgAdd
            // 
            this.dlgAdd.Enabled = false;
            this.dlgAdd.Location = new System.Drawing.Point(105, 13);
            this.dlgAdd.Name = "dlgAdd";
            this.dlgAdd.Size = new System.Drawing.Size(93, 28);
            this.dlgAdd.TabIndex = 3;
            this.dlgAdd.Text = "Add";
            this.dlgAdd.UseVisualStyleBackColor = true;
            // 
            // dlgDelete
            // 
            this.dlgDelete.Location = new System.Drawing.Point(419, 13);
            this.dlgDelete.Name = "dlgDelete";
            this.dlgDelete.Size = new System.Drawing.Size(93, 28);
            this.dlgDelete.TabIndex = 2;
            this.dlgDelete.Text = "Delete";
            this.dlgDelete.UseVisualStyleBackColor = true;
            // 
            // dlgEdit
            // 
            this.dlgEdit.Location = new System.Drawing.Point(320, 13);
            this.dlgEdit.Name = "dlgEdit";
            this.dlgEdit.Size = new System.Drawing.Size(93, 28);
            this.dlgEdit.TabIndex = 1;
            this.dlgEdit.Text = "Edit";
            this.dlgEdit.UseVisualStyleBackColor = true;
            // 
            // dlgAddNew
            // 
            this.dlgAddNew.Location = new System.Drawing.Point(6, 13);
            this.dlgAddNew.Name = "dlgAddNew";
            this.dlgAddNew.Size = new System.Drawing.Size(93, 28);
            this.dlgAddNew.TabIndex = 0;
            this.dlgAddNew.Text = "New Media";
            this.dlgAddNew.UseVisualStyleBackColor = true;
            this.dlgAddNew.Click += new System.EventHandler(this.dlgAddNew_Click);
            // 
            // moviesBindingSource1
            // 
            this.moviesBindingSource1.DataMember = "Movies";
            // 
            // inventory_form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(548, 532);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.dlgNewMedia);
            this.Controls.Add(this.groupBox1);
            this.MaximizeBox = false;
            this.Name = "inventory_form";
            this.Text = "Inventory";
            this.Load += new System.EventHandler(this.inventory_form_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dlgGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.moviesBindingSource)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.dlgNewMedia.ResumeLayout(false);
            this.dlgNewMedia.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.moviesBindingSource1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button dlgSearch;
        public System.Windows.Forms.DataGridView dlgGrid;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox dlgSearchText;
        private System.Windows.Forms.ComboBox dlgMedia;
        private System.Windows.Forms.GroupBox dlgNewMedia;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button dlgDelete;
        private System.Windows.Forms.Button dlgEdit;
        private System.Windows.Forms.Button dlgAddNew;
        private System.Windows.Forms.TextBox dlgCostBuy;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox dlgNumCopies;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox dlgQuality;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox dlgGenre;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox dlgDescription;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox dlgFullTitle;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox dlgRating;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button dlgAdd;
        private System.Windows.Forms.BindingSource moviesBindingSource;
        private System.Windows.Forms.BindingSource moviesBindingSource1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Available;
        private System.Windows.Forms.DataGridViewTextBoxColumn Title;
        private System.Windows.Forms.DataGridViewTextBoxColumn numCopies;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox comboBox1;
    }
}