using System;
using System.Collections.Generic;
using System.Text;

namespace Movie_Rental_Project
{
    public class member
    {
        #region variables
        private string address = null;
        private int id = 0;
        private string firstname = null;
        private string lastname = null;
        private string tel = null;
        private string cardname = null;
        private int cardnum = 0;
        private string expdate = null;
        private string status = null;
        private double outstanding = 0;
        #endregion

        #region properties
        public string Address
        {
            get { return address; }
            set { address = value; }
        }

        //Property for cardname
        public string Cardname
        {
            get { return cardname; }
            set { cardname = value; }
        }

        //Property for cardname
        public int Cardnum
        {
            get { return cardnum; }
            set { cardnum = value; }
        }

        public string Expdate
        {
            get { return expdate; }
            set { expdate = value; }
        }

        //Property for ID
        public int ID
        {
            get { return id; }
            set { id = value; }
        }

        //Property for Name
        public string Firstname
        {
            get { return firstname; }
            set { firstname = value; }
        }

        //Property for Name
        public string Lastname
        {
            get { return lastname; }
            set { lastname = value; }
        }

        //Property for Telephone Number
        public string Tel
        {
            get { return tel; }
            set { tel = value; }
        }

        //Property for Status
        public string Status
        {
            get { return status; }
            set { status = value; }
        }

        //Property for Outstanding Balance
        public double Outstanding
        {
            get { return outstanding; }
            set { outstanding = value; }
        }
        #endregion

        public member(string firstnamein, string lastnamein, string addressin, string telin, string cardnamein, int cardnumin, string expdatein)
        {

            firstname = firstnamein;
            lastname = lastnamein;
            address = addressin;
            tel = telin;
            cardname = cardnamein;
            cardnum = cardnumin;
            expdate = expdatein;

        }

        public member(string firstnamein, string lastnamein, string addressin, string telin)
        {
            firstname = firstnamein;
            lastname = lastnamein;
            address = addressin;
            tel = telin;
            cardname = null;
            cardnum = 0;
            expdate = null;
        }
        public member()
        {
        }
    }
}
