using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Movie_Rental_Project
{


    public partial class inventory_form : Form
    {
        public List<InventoryItem> ItemList = new List<InventoryItem>();

        public List<InventoryItem> ItemList1
        {
            get { return ItemList; }
            set { ItemList = value; }
        }

        public inventory_form()
        {
            InitializeComponent();
        }

        private void inventory_form_Load(object sender, EventArgs e)
        {
            OleDbConnection conn = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=Members1.mdb");
            conn.Open();    
            OleDbCommand aCommand = new OleDbCommand("SELECT * FROM Movies", conn);
            OleDbDataReader rdr = aCommand.ExecuteReader();
            
            while (rdr.Read())
            {

                InventoryItem TempItem = new InventoryItem();
                //Read one item
                TempItem.ID1 = rdr.GetInt32(0);
                TempItem.Title1 = rdr.GetString(1);
                TempItem.Description1 = rdr.GetString(2);
                TempItem.Rating1 = rdr.GetString(3);
                TempItem.NumCopies1 = rdr.GetInt32(4);
                TempItem.Cost1 = double.Parse(rdr.GetValue(5).ToString());
                TempItem.Genre1 = rdr.GetString(6);
                TempItem.MovieType1 = rdr.GetString(7);


                //Add to list and repeat
                ItemList.Add(TempItem);
            }              
            rdr.Close();
            conn.Close();

/*
            dataGridView1.Columns.Add("colName", "Name");
            dataGridView1.Columns.Add("colSurName", "Last Name");
            dataGridView1.Columns.Add("colAge", "Age");
            dataGridView1.Columns.Add("colGender", "Gender");
            dataGridView1.Columns.Add("colName", "E-mail");

            string[] DataResult1 = {"John", "Doe", "30", "Male", "J_Doe@mail.com"};
            string[] DataResult2 = {"Jane", "Doe", "25", "Female", "Jane_Doe@mail.com"};
            string[] DataResult3 = {"Patric", "O' Neil", "32", "Male", "P_O_Doe@mail.com"};
            string[] DataResult4 = {"Sue", "Baily", "23", "Female", "Sue_Baily@mail.com"};
            string[] DataResult5 = {"Wendy", "Wong", "28", "Female", "W_Wong@mail.com"};


            dataGridView1.Rows.Add(DataResult1);
            dataGridView1.Rows.Add(DataResult2);
            dataGridView1.Rows.Add(DataResult3);
            dataGridView1.Rows.Add(DataResult4);
            dataGridView1.Rows.Add(DataResult5);
           */

            //Populate list
            for(int x = 0; x < ItemList.Count; x++)
                dlgGrid.Rows.Add(ItemList[x].ID1, ItemList[x].Title1, ItemList[x].NumCopies1);


            //
           // DataGridView view = new DataGridView();
            
      


            
        }



        private void dlgGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        
        }

        private void dlgGrid_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex > ItemList.Count-1)
                return;

            if (e.RowIndex >= 0)
            {
                //We have row, now which ItemList

                int index = ItemList[e.RowIndex].ID1;
                index--;

                dlgFullTitle.Text = ItemList[index].Title1;
                dlgDescription.Text = ItemList[index].Description1;
                dlgGenre.Text = ItemList[index].Genre1;
                //TODO : Add quality
                dlgNumCopies.Text = ItemList[index].NumCopies1.ToString();
                dlgCostBuy.Text = ItemList[index].Cost1.ToString();
                dlgRating.Text = ItemList[index].Rating1;
            }
            else //sort it  ID titles copies
            {
                switch (e.ColumnIndex)
                {
                    case 1:
                        ItemList.Sort(delegate(InventoryItem p1, InventoryItem p2)
                        { return p1.ID1.CompareTo(p2.ID1); });
                      
                        //Clear them
                        dlgGrid.DataSource = null;
                        dlgGrid.Rows.Clear();

                   for(int x = 0; x < ItemList.Count; x++)
                        dlgGrid.Rows.Add(ItemList[x].ID1, ItemList[x].Title1, ItemList[x].NumCopies1);

                        break;

                    case 2:
                        ItemList.Sort(delegate(InventoryItem p1, InventoryItem p2)
                        { return p1.Title1.CompareTo(p2.Title1); });

                        //Clear them
                        dlgGrid.DataSource = null;
                        dlgGrid.Rows.Clear();

                        for (int x = 0; x < ItemList.Count; x++)
                            dlgGrid.Rows.Add(ItemList[x].ID1, ItemList[x].Title1, ItemList[x].NumCopies1);

                        break;

                    case 3:
                        ItemList.Sort(delegate(InventoryItem p1, InventoryItem p2)
                        { return p1.NumCopies1.CompareTo(p2.NumCopies1); });

                        //Clear them
                        dlgGrid.DataSource = null;
                        dlgGrid.Rows.Clear();

                        for (int x = 0; x < ItemList.Count; x++)
                            dlgGrid.Rows.Add(ItemList[x].ID1, ItemList[x].Title1, ItemList[x].NumCopies1);


                        break;

                    default:
                        //error
                        break;





                }



            }
        }

        private void dlgAddNew_Click(object sender, EventArgs e)
        {
            NewMedia mediadlg = new NewMedia();
            mediadlg.Owner = this;
            mediadlg.Show();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void dlgSearch_Click(object sender, EventArgs e)
        {
            string searchString = dlgSearchText.Text;
            for (int x = 0; x < ItemList.Count; x++)
            {
                if (ItemList[x].Title1.Contains(searchString))
                {
                    dlgGrid.Rows[x].Selected = true;
                    dlgGrid.Rows[x].Visible = true;
                }
            }
        }

        private void dlgNewMedia_Enter(object sender, EventArgs e)
        {

        }

        private void dlgSearchText_TextChanged(object sender, EventArgs e)
        {

        }


    }
}