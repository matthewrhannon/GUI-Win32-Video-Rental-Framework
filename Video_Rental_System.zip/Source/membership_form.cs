using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;


namespace Movie_Rental_Project
{
    public partial class membership_form : Form
    {

        public List<member> memberList = new List<member>();

        public List<member> MemberList
        {
            get { return memberList; }
            set { memberList = value; }
        }

        public membership_form()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Create an instance of Create_Member.
            Create_Member dlg = new Create_Member();


            // If user clicked OK button, render their message.
            if (DialogResult.OK == dlg.ShowDialog())
            {
            }

            dlg.Dispose();
        }

        private void infoLabel_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void membership_form_Load(object sender, EventArgs e)
        {
            OleDbConnection conn = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=Members1.mdb");
            conn.Open();
            OleDbCommand aCommand = new OleDbCommand("SELECT * FROM Members", conn);
            OleDbDataReader rdr = aCommand.ExecuteReader();

            while (rdr.Read())
            {

                member TempMember = new member();
                //Read one member
                TempMember.ID = rdr.GetInt32(0);
                TempMember.Firstname = rdr.GetString(1);
                TempMember.Lastname = rdr.GetString(2);
                TempMember.Address = rdr.GetString(3);
                TempMember.Tel = rdr.GetString(4);
                TempMember.Status = rdr.GetString(5);
                TempMember.Outstanding = double.Parse(rdr.GetValue(6).ToString());
                TempMember.Cardname = rdr.GetString(7);
                TempMember.Cardnum = rdr.GetInt32(8);
                TempMember.Expdate = rdr.GetString(9);

                //Add to list and repeat
                memberList.Add(TempMember);
            }

            rdr.Close();
            conn.Close();
        }

    }
}