using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Movie_Rental_Project
{
     public partial class transaction_form : Form
     {
          public transaction_form()
          {
               InitializeComponent();
          }

          private void transaction_form_Load(object sender, EventArgs e)
          {

          }
     }
}