using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Movie_Rental_Project
{
    public partial class Create_Member : Form
    {
        public Create_Member()
        {
            InitializeComponent();
        }
    }
}