using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Movie_Rental_Project
{
    public partial class NewMedia : Form
    {
        public static inventory_form parent = new inventory_form();
        public NewMedia()
        {
            InitializeComponent();
        }

        private void NewMedia_Load(object sender, EventArgs e)
        {
            parent = (Movie_Rental_Project.inventory_form)this.Owner;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            InventoryItem temp = new InventoryItem();
 
            temp.ID1 = parent.ItemList1.Count + 1;
            temp.Title1 = textBox7.Text;
            temp.Description1 = textBox6.Text;
            temp.Genre1 = textBox5.Text;
            temp.Quality1 = textBox4.Text;
            temp.NumCopies1 = int.Parse(textBox3.Text);
            temp.Cost1 = double.Parse(textBox2.Text);
            temp.Rating1 = textBox1.Text;
            temp.Media1 = comboBox1.SelectedItem.ToString();

            parent.ItemList1.Add(temp);

            //Clear it
            parent.dlgGrid.DataSource = null;
            parent.dlgGrid.Rows.Clear();

            //Populate list
            for (int x = 0; x < parent.ItemList.Count; x++)
                parent.dlgGrid.Rows.Add(parent.ItemList[x].ID1, parent.ItemList[x].Title1, parent.ItemList[x].NumCopies1);


        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

    }
}
