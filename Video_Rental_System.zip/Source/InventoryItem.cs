using System;
using System.Collections.Generic;
using System.Text;


namespace Movie_Rental_Project
{
    public class InventoryItem
    {
        public InventoryItem()
        {
        }

        public InventoryItem(int id, string title, string descrip, string rating, int copies, double cost, string genre, string type)
        {
            ID = id;
            Title = title;
            Description = descrip;
            Rating = rating;
            NumCopies = copies;
            Cost = cost;
            Genre = genre;
            MovieType = type;
        }
        private int ID;

        public int ID1
        {
          get { return ID; }
          set { ID = value; }
        }
        private string Title;

        public string Title1
        {
          get { return Title; }
          set { Title = value; }
        }
        private string Description;

        public string Description1
        {
          get { return Description; }
          set { Description = value; }
        }
        private string Rating;

        public string Rating1
        {
          get { return Rating; }
          set { Rating = value; }
        }
        private int NumCopies;

        public int NumCopies1
        {
          get { return NumCopies; }
          set { NumCopies = value; }
        }
        private double Cost;

        public double Cost1
        {
          get { return Cost; }
          set { Cost = value; }
        }
        private string Genre;

        public string Genre1
        {
          get { return Genre; }
          set { Genre = value; }
        }
        private string MovieType;

        public string MovieType1 //standard new.
        {
          get { return MovieType; }
          set { MovieType = value; }
        }

        private string Quality;

        public string Quality1
        {
            get { return Quality; }
            set { Quality = value; }
        }

        private string Media;

        public string Media1
        {
            get { return Media; }
            set { Media = value; }
        }

    }
}
